package Entity;

public class Project {
    private String projectId;
    private String projectName;
    private String projectType;
    private String startDate;
    private String endDate;
    private String status;
    private double budget;
    private String itFirmId;

    public Project(String projectId, String projectName, String projectType, String startDate, String endDate, String status, double budget, String itFirmId) {
        setProjectId(projectId);
        setProjectName(projectName);
        setProjectType(projectType);
        setStartDate(startDate);
        setEndDate(endDate);
        setStatus(status);
        setBudget(budget);
        setItFirmId(itFirmId);
    }

    public String getProjectId() { return projectId; }
    public void setProjectId(String projectId) { this.projectId = projectId; }

    public String getProjectName() { return projectName; }
    public void setProjectName(String projectName) { this.projectName = projectName; }

    public String getProjectType() { return projectType; }
    public void setProjectType(String projectType) { this.projectType = projectType; }

    public String getStartDate() { return startDate; }
    public void setStartDate(String startDate) { this.startDate = startDate; }

    public String getEndDate() { return endDate; }
    public void setEndDate(String endDate) { this.endDate = endDate; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public double getBudget() { return budget; }
    public void setBudget(double budget) { this.budget = budget; }

    public String getItFirmId() { return itFirmId; }
    public void setItFirmId(String itFirmId) { this.itFirmId = itFirmId; }
}
