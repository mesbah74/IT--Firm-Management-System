package Entity;

public class User {
    private String userId;
    private String userName;
    private String email;
    private String password;

    public User(String userId, String userName, String email, String password) {
        setUserId(userId);
        setUserName(userName);
        setEmail(email);
        setPassword(password);
    }
    
    public User(String userName, String email, String password) {
        this(null, userName, email, password); // Calls the main constructor with userId as null
    }


    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "User ID: " + userId + "\n" +
               "User Name: " + userName + "\n" +
               "Email: " + email;
    }
}
