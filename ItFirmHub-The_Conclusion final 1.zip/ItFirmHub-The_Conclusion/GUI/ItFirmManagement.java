package GUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Vector;

import Entity.ItFirm;
import EntityList.ItFirmList;
import Files.FileIO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException; 
import java.sql.ResultSet;


public class ItFirmManagement extends JFrame implements ActionListener {
    Font titleFont = new Font("RockWell",Font.BOLD,30);
    Font labelFont = new Font("Cambria",Font.BOLD,15);
    Font buttonFont = new Font("Cambria", Font.BOLD,15);

    JTextField idTextField, nameTextField, ceoTextField, projectDoneTextField, employeeNumberTextField, vacancyTextField, rankingTextField, addressTextField, contactNumberTextField, emailAddressTextField;
    JTextField searchTextField;
    JTextArea displayArea;
    JButton addButton, updateButton, removeButton, searchButton, showAllButton, clearScreenButton,logOutButton,addProjectDetailsButton;
    JComboBox<String> itFirmTypeBox;
    JComboBox<Integer> establishedYearBox;
    JComboBox<String> sortByBox;
    ItFirmList itFirmList = new ItFirmList();
    public JFrame previousPage;

    public ItFirmManagement(String role) {
        this();

        if ("Admin".equals(role)) {

        }
        else if("User".equalsIgnoreCase(role)){
            addButton.setEnabled(false);
            updateButton.setEnabled(false);
            removeButton.setEnabled(false);
            addProjectDetailsButton.setEnabled(false);
            addButton.setVisible(false);
            updateButton.setVisible(false);
            removeButton.setVisible(false);
            addProjectDetailsButton.setVisible(false);
        }
        else {

        }
    }


    public ItFirmManagement(){
        super("It Firm Hub ");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setSize(1200,700);
        this.setLocationRelativeTo(null); //for center of windows
        //this.setResizable(false);
        this.getContentPane().setBackground(new Color(227, 237, 247));
        this.setLayout(null);

        //load data from file
        FileIO.loadItFirmFromFile(itFirmList);

        //title
        JLabel titleLabel = new JLabel("ItFirm Hub Management");
        titleLabel.setBounds(330,15,600,50);
        titleLabel.setFont(titleFont);
        this.add(titleLabel);

        //sub title

        //ItFirm Entry Form
        int top = 80;
        int gap = 40;

        //Id
        JLabel firmIdLabel = new JLabel("Firm ID");
        firmIdLabel.setBounds(50,top,200,30);
        firmIdLabel.setFont(labelFont);
        this.add(firmIdLabel);

        idTextField = new JTextField();
        idTextField.setBounds(200,top,200,30);
        idTextField.setFont(labelFont);
        idTextField.setBackground(new Color(230, 230, 230));
        this.add(idTextField);

        //Name
        JLabel firmNameLabel = new JLabel("Firm Name");
        firmNameLabel.setBounds(50, top+=gap, 200,30);
        firmNameLabel.setFont(labelFont);
        this.add(firmNameLabel);

         nameTextField = new JTextField();
         nameTextField.setBounds(200, top, 200,30);
         nameTextField.setFont(labelFont);
         nameTextField.setBackground(new Color(230, 230, 230));
         this.add(nameTextField);

         //CEO name
        JLabel ceoNameLabel = new JLabel("CEO Name");
        ceoNameLabel.setBounds(50,top+=gap,200,30);
        ceoNameLabel.setFont(labelFont);
        this.add(ceoNameLabel);

        ceoTextField  = new JTextField();
        ceoTextField.setBounds(200,top,200,30);
        ceoTextField.setFont(labelFont);
        ceoTextField.setBackground(new Color(230, 230, 230));
        this.add(ceoTextField);

        //Established year, need to change date to year
        JLabel establishedYearLabel = new JLabel("Established Year");
        establishedYearLabel.setBounds(50,top+=gap, 200,30);
        establishedYearLabel.setFont(labelFont);
        this.add(establishedYearLabel);

        /*establishedYearTextField = new JTextField();
        establishedYearTextField.setBounds(200,top,200,30);
        establishedYearTextField.setFont(labelFont);
        this.add(establishedYearTextField);*/
        establishedYearBox = new JComboBox<>();
        Calendar now = Calendar.getInstance();
        int year = now.get(Calendar.YEAR);
        Vector<Integer> v = new Vector<>();
        for(int i = year; i>=1980; i--){
            v.add(i);
        }
        establishedYearBox.setModel(new DefaultComboBoxModel<>(v));
        establishedYearBox.setSelectedIndex(-1);
        establishedYearBox.setBounds(200,top,200,30);
        establishedYearBox.setFont(labelFont);
        establishedYearBox.setBackground(new Color(230, 230, 230));
        this.add(establishedYearBox);

        //Projects
        JLabel projectDoneLabel = new JLabel("Projects");
        projectDoneLabel.setBounds(50, top+=gap,200,30);
        projectDoneLabel.setFont(labelFont);
        this.add(projectDoneLabel);

        projectDoneTextField = new JTextField();
        projectDoneTextField.setBounds(200,top, 200,30);
        projectDoneTextField.setFont(labelFont);
        projectDoneTextField.setBackground(new Color(230, 230, 230));
        this.add(projectDoneTextField);

        //Employee Number
        JLabel employeeNumberLabel = new JLabel("Employees");
        employeeNumberLabel.setBounds(50, top+=gap, 200,30);
        employeeNumberLabel.setFont(labelFont);
        this.add(employeeNumberLabel);

        employeeNumberTextField = new JTextField();
        employeeNumberTextField.setBounds(200, top, 200,30);
        employeeNumberTextField.setFont(labelFont);
        employeeNumberTextField.setBackground(new Color(230, 230, 230));
        this.add(employeeNumberTextField);

        //Vacancy
        JLabel vacancyLabel = new JLabel("Vacancy");
        vacancyLabel.setBounds(50, top+=gap, 200,30);
        vacancyLabel.setFont(labelFont);
        this.add(vacancyLabel);

        vacancyTextField = new JTextField();
        vacancyTextField.setBounds(200,top,200,30);
        vacancyTextField.setFont(labelFont);
        vacancyTextField.setBackground(new Color(230, 230, 230));
        this.add(vacancyTextField);

        //FirmType
        JLabel firmTypeLabel = new JLabel("Firm Type");
        firmTypeLabel.setBounds(50, top+=gap,200,30);
        firmTypeLabel.setFont(labelFont);
        this.add(firmTypeLabel);

        /*firmTypeTextField =new JTextField();
        firmTypeTextField.setBounds(200, top, 200, 30);
        firmTypeTextField.setFont(labelFont);
        this.add(firmTypeTextField);*/
        itFirmTypeBox = new JComboBox<>(new String[]{"Full-Service IT Solutions","Software  Development","Cloud Management","Web Development","Mobile App Development","Cyber Security","AI and Mechine Learning"});
        itFirmTypeBox.setBounds(200,top,200,30);
        itFirmTypeBox.setFont(new Font("Cambria",Font.BOLD,14));
        itFirmTypeBox.setSelectedIndex(-1);
        itFirmTypeBox.setBackground(new Color(230, 230, 230));
        this.add(itFirmTypeBox);

        //Ranking
        JLabel rankingLabel = new JLabel("Ranking");
        rankingLabel.setBounds(50,top+=gap,200,30);
        rankingLabel.setFont(labelFont);
        this.add(rankingLabel);

        rankingTextField = new JTextField();
        rankingTextField.setBounds(200,top,200,30);
        rankingTextField.setFont(labelFont);
        rankingTextField.setBackground(new Color(230, 230, 230));
        this.add(rankingTextField);

        //Address
        JLabel addressLabel = new JLabel("Address");
        addressLabel.setBounds(50,top+=gap,200,30);
        addressLabel.setFont(labelFont);
        this.add(addressLabel);

        addressTextField = new JTextField();
        addressTextField.setBounds(200,top,200,30);
        addressTextField.setFont(labelFont);
        addressTextField.setBackground(new Color(230, 230, 230));
        this.add(addressTextField);

        //Contact Number
        JLabel contactNumberLabel= new JLabel("Contact Number");
        contactNumberLabel.setBounds(50,top+=gap,200,30);
        contactNumberLabel.setFont(labelFont);
        this.add(contactNumberLabel);

        contactNumberTextField = new JTextField();
        contactNumberTextField.setBounds(200,top,200,30);
        contactNumberTextField.setFont(labelFont);
        contactNumberTextField.setBackground(new Color(230, 230, 230));
        this.add(contactNumberTextField);

        //Email Address
        JLabel emailAddressLabel = new JLabel("Email Address");
        emailAddressLabel.setBounds(50,top+=gap,200,30);
        emailAddressLabel.setFont(labelFont);
        this.add(emailAddressLabel);

        emailAddressTextField =new JTextField();
        emailAddressTextField.setBounds(200,top,200,30);
        emailAddressTextField.setFont(labelFont);
        emailAddressTextField.setBackground(new Color(230, 230, 230));
        this.add(emailAddressTextField);

        //ItFirm Entry Buttons
        addButton = new JButton("Add Firm");
        addButton.setBounds(50, top+=gap+20,130,30);
        addButton.setBackground(new Color(25, 118, 210));
        addButton.setForeground(Color.WHITE);
        addButton.setFont(buttonFont);
        this.add(addButton);
        addButton.addActionListener(this);

        updateButton = new JButton("Update Firm");
        updateButton.setBounds(200, top,130,30);
        updateButton.setFont(buttonFont);
        updateButton.setBackground(new Color(255, 165, 0));
        this.add(updateButton);
        updateButton.addActionListener(this);

        removeButton = new JButton("Remove Firm");
        removeButton.setBounds(350,top,130,30);
        removeButton.setFont(buttonFont);
        removeButton.setBackground(new Color(220, 53, 69));
        removeButton.setForeground(Color.WHITE);
        this.add(removeButton);
        removeButton.addActionListener(this);

        //Add Project Details button
        addProjectDetailsButton = new JButton("Add Project Details");
        addProjectDetailsButton.setBounds(175, 620, 180, 25);
        addProjectDetailsButton.setFont(buttonFont);
        addProjectDetailsButton.setBackground(new Color(0, 123, 255));
        addProjectDetailsButton.setForeground(Color.WHITE);
        this.add(addProjectDetailsButton);
        addProjectDetailsButton.addActionListener(this);

        //Disply Area
        displayArea = new JTextArea();
        displayArea.setBounds(450,80,700,469);
        displayArea.setFont(new Font("Segoe UI",Font.PLAIN,15));
        displayArea.setBackground(new Color(245, 245, 245));
        displayArea.setForeground(Color.BLACK);
        displayArea.setCaretPosition(0);
        displayArea.setEditable(false); //No one can write or edit in Disply Area
        JScrollPane scrollPane = new JScrollPane(displayArea);
        scrollPane.setBounds(450,80,700,469);
        this.add(scrollPane);
        

        displayArea.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                try {
                    int clickedLine = displayArea.getLineOfOffset(displayArea.viewToModel2D(e.getPoint()));
                    String line = getLineText(displayArea, clickedLine);
                    if (line.contains("[Click To Show Project Details]")) {
                        String firmIdLine = getLineText(displayArea, clickedLine - 12);
                        String firmNameLine = getLineText(displayArea, clickedLine - 11);
                        String firmId = firmIdLine.split(":")[1].trim();
                        String firmName = firmNameLine.split(":")[1].trim();

                        String projects = FileIO.loadProjectsFromFile(firmId);
                        JOptionPane.showMessageDialog(null, projects,
                                "Projects of " + firmName,
                                JOptionPane.INFORMATION_MESSAGE);
                    }
                } catch (Exception ex) {
                    System.out.println("Error handling click: " + ex.getMessage());
                }
            }

            private String getLineText(JTextArea textArea, int lineNumber) {
                try {
                    int start = textArea.getLineStartOffset(lineNumber);
                    int end = textArea.getLineEndOffset(lineNumber);
                    return textArea.getText(start, end - start);
                } catch (Exception e) {
                    return "";
                }
            }
        });




        //Search
        JLabel searchLabel = new JLabel("Search By:");
        searchLabel.setBounds(765,20,110,25);
        searchLabel.setFont(labelFont);
        this.add(searchLabel);

        searchTextField = new JTextField();
        searchTextField.setBounds(850, 20, 165 , 25);
        searchTextField.setFont(labelFont);
        searchTextField.setBackground(new Color(230, 230, 230));
        this.add(searchTextField);

        searchButton = new JButton("Search");
        searchButton.setBounds(1030,20,120,25);
        searchButton.setFont(buttonFont);
        searchButton.setBackground(new Color(54, 185, 64));
        searchButton.setForeground(Color.WHITE);
        this.add(searchButton);
        searchButton.addActionListener(this);

        //sorting
        JLabel sortLabel = new JLabel("Sort By");
        sortLabel.setBounds(960,55,110,20);
        sortLabel.setFont(labelFont);
        this.add(sortLabel);

        sortByBox = new JComboBox<>(new String[]{"ID (ASC)", "Name (ASC)", "Name (DESC)", "Vacancy", "Firm Type (ASC)"});
        sortByBox.setBounds(1020, 55, 130, 20);
        sortByBox.setFont(labelFont);
        sortByBox.setBackground(new Color(230, 230, 230));
        sortByBox.setSelectedIndex(-1);
        this.add(sortByBox);
        sortByBox.addActionListener(this);

        //Show All
        showAllButton = new JButton("Show All Firms");
        showAllButton.setBounds(600,top,160,30);
        showAllButton.setFont(buttonFont);
        this.add(showAllButton);
        showAllButton.addActionListener(this);

        //Clear Screen
        clearScreenButton=new JButton("Clear Screen");
        clearScreenButton.setBounds(780,top,160,30);
        clearScreenButton.setFont(buttonFont);
        this.add(clearScreenButton);
        clearScreenButton.addActionListener(this);

        //delete
        logOutButton = new JButton("LogOut");
        logOutButton.setBounds(1030,620,120,30);
        logOutButton.setFont(buttonFont);
        logOutButton.setBackground(Color.RED);
        logOutButton.setForeground(Color.WHITE);
        this.add(logOutButton);
        logOutButton.addActionListener(this);
        reloadData();

        //visiblity
        this.setVisible(true);
    }

    //
    public void actionPerformed(ActionEvent e) {
    	if (addButton == e.getSource()) {
    	    System.out.println("ADD CLICKED"); 
    	    try {
    	        int id = Integer.parseInt(idTextField.getText());
    	        ItFirm firm = itFirmList.getById(idTextField.getText());
    	        if (firm == null) {
    	            if (!idTextField.getText().isEmpty() &&
    	                    !nameTextField.getText().isEmpty() &&
    	                    !ceoTextField.getText().isEmpty() &&
    	                    establishedYearBox.getSelectedItem() != null &&
    	                    !projectDoneTextField.getText().isEmpty() &&
    	                    !employeeNumberTextField.getText().isEmpty() &&
    	                    !vacancyTextField.getText().isEmpty() &&
    	                    itFirmTypeBox.getSelectedItem() != null &&
    	                    !rankingTextField.getText().isEmpty() &&
    	                    !addressTextField.getText().isEmpty() &&
    	                    !contactNumberTextField.getText().isEmpty() &&
    	                    !emailAddressTextField.getText().isEmpty() ) {
                        if (!emailAddressTextField.getText().endsWith("@gmail.com")) {
                            JOptionPane.showMessageDialog(this, "Email must end with @gmail.com");
                            return;
                        }

                        try {
    	                    ItFirm tempFirm = new ItFirm(idTextField.getText(), nameTextField.getText(), ceoTextField.getText(), establishedYearBox.getSelectedItem().toString(), Integer.parseInt(projectDoneTextField.getText()), Short.parseShort(employeeNumberTextField.getText()), Integer.parseInt(vacancyTextField.getText()), itFirmTypeBox.getSelectedItem().toString(), rankingTextField.getText(), addressTextField.getText(), contactNumberTextField.getText(), emailAddressTextField.getText());
    	                    itFirmList.insert(tempFirm);
    	                    //file I/O
    	                    FileIO.writeItFirmInFile(tempFirm);

    	                    // Database Insertion - Moved to outer try block
    	                    Connection conn = null;
    	                    PreparedStatement pstmt = null;
    	                    try {
    	                        conn = ItFirmManagementSystem.getConnection();  
    	                        String sql = "INSERT INTO ItFirms (itFirmId, itFirmName, ceoName, establishedDate, numberOfProjectDone, totalEmployeeNumber, vacancy, firmType, ranking, firmAddress, contactNumber, emailAddress) " +
    	                                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    	                        pstmt = conn.prepareStatement(sql);
    	                        pstmt.setString(1, tempFirm.getItFirmId());
    	                        pstmt.setString(2, tempFirm.getItFirmName());
    	                        pstmt.setString(3, tempFirm.getCeoName());
    	                        pstmt.setString(4, tempFirm.getEstablishedDate());
    	                        pstmt.setInt(5, tempFirm.getNumberOfProjectDone());
    	                        pstmt.setInt(6, tempFirm.getTotalEmployeeNumber()); 
    	                        pstmt.setInt(7, tempFirm.getVacancy());
    	                        pstmt.setString(8, tempFirm.getFirmType());
    	                        pstmt.setString(9, tempFirm.getRanking());
    	                        pstmt.setString(10, tempFirm.getFirmAddress());
    	                        pstmt.setString(11, tempFirm.getContactNumber());
    	                        pstmt.setString(12, tempFirm.getEmailAddress());

    	                        int rowsInserted = pstmt.executeUpdate();
    	                        if (rowsInserted > 0) {
    	                            System.out.println("A new It Firm was inserted successfully!");
    	                            // Clear input fields if insertion was successful
    	                            clearInputFields(); 
    	                            reloadData();
    	                        }
    	                    } catch (SQLException ex) {
    	                        ex.printStackTrace();
    	                        JOptionPane.showMessageDialog(this, "Error inserting into database", "Database Error", JOptionPane.ERROR_MESSAGE);
    	                    } catch (ClassNotFoundException ex) {
    	                        throw new RuntimeException(ex);
    	                    } finally {
    	                        // Close resources in a finally block
    	                        try {
    	                            if (pstmt != null) pstmt.close();
    	                        } catch (SQLException ex) {
    	                            ex.printStackTrace();
    	                        }
    	                        ItFirmManagementSystem.closeConnection(conn);
    	                    }

    	                    JOptionPane.showMessageDialog(this, "Firm Added");
    	                    reloadData();
    	                } catch (NumberFormatException NFE) {
    	                    JOptionPane.showMessageDialog(this, "Invalid Input Format");
    	                } 
    	                // Catch blocks for database operations are now at the same level
    	            } else { //... (rest of your validation logic) ... 
    	            }
    	        } else { 
    	            JOptionPane.showMessageDialog(this, "ItFirm ID Already Used");
    	        }
    	    } catch (NumberFormatException nFE){
    	        JOptionPane.showMessageDialog(this,"ID must be an integer");
    	    }
    	    displayArea.setCaretPosition(0);
    	} 

        
    	else if (updateButton == e.getSource()) {
    	    System.out.println("UPDATE CLICKED");

    	    String itFirmId = idTextField.getText();
    	    if (itFirmList.getById(itFirmId) == null) {
    	        JOptionPane.showMessageDialog(this, "No Firm Found");
    	        return;
    	    }

    	    // Check and retain existing values for empty fields
    	    String itFirmName = nameTextField.getText().isEmpty() ? itFirmList.getById(itFirmId).getItFirmName() : nameTextField.getText();
    	    String ceoName = ceoTextField.getText().isEmpty() ? itFirmList.getById(itFirmId).getCeoName() : ceoTextField.getText();
    	    String ranking = rankingTextField.getText().isEmpty() ? itFirmList.getById(itFirmId).getRanking() : rankingTextField.getText();
    	    String address = addressTextField.getText().isEmpty() ? itFirmList.getById(itFirmId).getFirmAddress() : addressTextField.getText();
    	    String contactNumber = contactNumberTextField.getText().isEmpty() ? itFirmList.getById(itFirmId).getContactNumber() : contactNumberTextField.getText();
    	    String emailAddress = emailAddressTextField.getText().isEmpty() ? itFirmList.getById(itFirmId).getEmailAddress() : emailAddressTextField.getText();
    	    String establishedYear = establishedYearBox.getSelectedIndex() != -1 ? establishedYearBox.getSelectedItem().toString() : itFirmList.getById(itFirmId).getEstablishedDate();
    	    int numberOfProjectDone = projectDoneTextField.getText().isEmpty() ? itFirmList.getById(itFirmId).getNumberOfProjectDone() : Integer.parseInt(projectDoneTextField.getText());
    	    short totalEmployeeNumber = employeeNumberTextField.getText().isEmpty() ? (short) itFirmList.getById(itFirmId).getTotalEmployeeNumber() : Short.parseShort(employeeNumberTextField.getText());
    	    int vacancy = vacancyTextField.getText().isEmpty() ? itFirmList.getById(itFirmId).getVacancy() : Integer.parseInt(vacancyTextField.getText());
    	    String firmType = itFirmTypeBox.getSelectedIndex() != -1 ? itFirmTypeBox.getSelectedItem().toString() : itFirmList.getById(itFirmId).getFirmType();

    	    // Create updated ItFirm object
    	    ItFirm tempFirm = new ItFirm(itFirmId, itFirmName, ceoName, establishedYear, numberOfProjectDone, totalEmployeeNumber, vacancy, firmType, ranking, address, contactNumber, emailAddress);

    	    try {
    	        // Call the update method
    	        updateItFirmInDatabase(tempFirm);

    	        // Refresh the GUI with updated data
    	        reloadData();

    	        // Show success message AFTER updating
    	        JOptionPane.showMessageDialog(this, "Firm Updated Successfully");

    	    } catch (SQLException | ClassNotFoundException ex) {
    	        ex.printStackTrace();
    	        JOptionPane.showMessageDialog(this, "Error updating database", "Database Error", JOptionPane.ERROR_MESSAGE);
    	    }
    	    displayArea.setCaretPosition(0);
    	}



    	else if(searchButton == e.getSource()){
            System.out.println("SEARCH CLICKED");
            String searchInput = searchTextField.getText().trim();
            if(searchInput.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter search text");
                return;
            }
            ItFirm firm;
            StringBuilder results = new StringBuilder();
            try {
                int firmId = Integer.parseInt(searchInput);
                firm = itFirmList.getById(String.valueOf(firmId));
                if(firm != null) {
                    displayArea.setText(firm.getItFirmAsString());
                } else {
                    JOptionPane.showMessageDialog(this, "No ItFirm Found with this ID");
                }
            }
            catch(NumberFormatException nFE){
                boolean found = false;
                for(ItFirm f : itFirmList.getAllFirms()) {
                    if(f != null && f.getItFirmName().toLowerCase()
                            .startsWith(searchInput.toLowerCase()))
                    {
                        if(found) {
                            results.append("\n----------------------------------------------------------------------------------------------------------\n");
                        }
                        results.append(f.getItFirmAsString());
                        found = true;
                    }
                }

                if(found) {
                    displayArea.setText(results.toString());
                } else {
                    JOptionPane.showMessageDialog(this, "No ItFirm Found with this name");
                }
            }
        }




        else if (removeButton == e.getSource()) {
            System.out.println("REMOVE CLICKED");

            // Get the ID of the firm to delete
            String itFirmId = idTextField.getText();

            // Check if the firm exists
            ItFirm firmToDelete = itFirmList.getById(itFirmId);
            if (firmToDelete == null) {
                JOptionPane.showMessageDialog(this, "No Firm Found");
                return;
            }

            // Confirm deletion
            int confirmation = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this firm?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);
            if (confirmation != JOptionPane.YES_OPTION) {
                return; // Exit if the user cancels
            }

            try {
                // Delete the firm from the database
                deleteItFirmFromDatabase(itFirmId);

                // Remove the firm from the in-memory list
                itFirmList.removeById(itFirmId);

                // Refresh the UI
                reloadData();

                // Show success message
                JOptionPane.showMessageDialog(this, "Firm Deleted Successfully");

            } catch (SQLException | ClassNotFoundException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error deleting firm from database", "Database Error", JOptionPane.ERROR_MESSAGE);
            }
            displayArea.setCaretPosition(0);
        }


        else if(showAllButton == e.getSource()){
            System.out.println("SHOW ALL CLICKED");
            FileIO.reWriteItFirmInFile(itFirmList);
            reloadData();
            displayArea.setCaretPosition(0);
        }

        else if(clearScreenButton == e.getSource()){
            System.out.println("CLEAR SCREEN CLICKED");
            idTextField.setText("");
            nameTextField.setText("");
            ceoTextField.setText("");
            establishedYearBox.setSelectedIndex(-1);
            projectDoneTextField.setText("");
            employeeNumberTextField.setText("");
            vacancyTextField.setText("");
            itFirmTypeBox.setSelectedIndex(-1);
            rankingTextField.setText("");
            addressTextField.setText("");
            contactNumberTextField.setText("");
            emailAddressTextField.setText("");
            displayArea.setText("");
            JOptionPane.showMessageDialog(this,"Cleared Successfully");
            displayArea.setCaretPosition(0);
        }

        else if(logOutButton == e.getSource()){
            System.out.println("LogOut Button CLICKED");
           previousPage.setVisible(true);
            this.dispose();
        }
    	
    	if (e.getSource() == addProjectDetailsButton) {
            ProjectDetailsDialog dialog = new ProjectDetailsDialog();
            dialog.setVisible(true);
        }
    	
    	
        else if (sortByBox == e.getSource()) {
            String selectedSort = (String) sortByBox.getSelectedItem();
            if (selectedSort != null) {
                ItFirm[] firms = itFirmList.getAllFirms();
                switch (selectedSort) {
                    case "ID (ASC)":
                        insertionSort(firms, Comparator.comparingInt(firm -> Integer.parseInt(firm.getItFirmId())));
                        break;
                    case "Name (ASC)":
                        insertionSort(firms, Comparator.comparing(ItFirm::getItFirmName, String::compareToIgnoreCase));
                        break;
                    case "Name (DESC)":
                        insertionSort(firms, Comparator.comparing(ItFirm::getItFirmName, String::compareToIgnoreCase).reversed());
                        break;
                    case "Vacancy":
                        insertionSort(firms, Comparator.comparingInt(ItFirm::getVacancy).reversed());
                        break;
                    case "Firm Type (ASC)":
                        insertionSort(firms, Comparator.comparing(ItFirm::getFirmType, Comparator.nullsLast(Comparator.naturalOrder())));
                        break;
                }
                reloadData();
                displayArea.setCaretPosition(0);
            }
        }
    	displayArea.setCaretPosition(0);

    }

    //Reload
    public void reloadData() {
    	if (sortByBox != null) {
            sortByBox.setSelectedItem("ID (ASC)");
        }
        // Fetch all firms and update the display area
        displayArea.setText(itFirmList.getAllItFirmAsString());
     
    }
    
    private void insertionSort(ItFirm[] array, Comparator<ItFirm> comparator) {
        for (int i = 1; i < array.length; i++) {
            ItFirm key = array[i];
            if (key == null) continue;
            int j = i - 1;
            while (j >= 0 && array[j] != null && comparator.compare(array[j], key) > 0) {
                array[j + 1] = array[j];
                j = j - 1;
            }
            if (j + 1 >= 0) {
                array[j + 1] = key;
            }
        }
    }
    
    
    private void clearInputFields() {
        idTextField.setText("");
        nameTextField.setText("");
        ceoTextField.setText("");
        establishedYearBox.setSelectedIndex(-1); // Reset combo box
        projectDoneTextField.setText("");
        employeeNumberTextField.setText("");
        vacancyTextField.setText("");
        itFirmTypeBox.setSelectedIndex(-1);      // Reset combo box
        rankingTextField.setText("");
        addressTextField.setText("");
        contactNumberTextField.setText("");
        emailAddressTextField.setText("");
    } 
    
    public void updateItFirmInDatabase(ItFirm tempFirm) throws SQLException, ClassNotFoundException {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = ItFirmManagementSystem.getConnection();

            // Start building the SQL query
            StringBuilder sql = new StringBuilder("UPDATE ItFirms SET ");
            java.util.List<String> parameters = new ArrayList<>();

            // Dynamically add fields that are non-null and non-empty
            if (tempFirm.getItFirmName() != null && !tempFirm.getItFirmName().isEmpty()) {
                parameters.add("itFirmName = ?");
            }
            if (tempFirm.getCeoName() != null && !tempFirm.getCeoName().isEmpty()) {
                parameters.add("ceoName = ?");
            }
            if (tempFirm.getEstablishedDate() != null && !tempFirm.getEstablishedDate().isEmpty()) {
                parameters.add("establishedDate = ?");
            }
            if (tempFirm.getNumberOfProjectDone() != 0) {
                parameters.add("numberOfProjectDone = ?");
            }
            if (tempFirm.getTotalEmployeeNumber() != 0) {
                parameters.add("totalEmployeeNumber = ?");
            }
            if (tempFirm.getVacancy() != 0) {
                parameters.add("vacancy = ?");
            }
            if (tempFirm.getFirmType() != null && !tempFirm.getFirmType().isEmpty()) {
                parameters.add("firmType = ?");
            }
            if (tempFirm.getRanking() != null && !tempFirm.getRanking().isEmpty()) {
                parameters.add("ranking = ?");
            }
            if (tempFirm.getFirmAddress() != null && !tempFirm.getFirmAddress().isEmpty()) {
                parameters.add("firmAddress = ?");
            }
            if (tempFirm.getContactNumber() != null && !tempFirm.getContactNumber().isEmpty()) {
                parameters.add("contactNumber = ?");
            }
            if (tempFirm.getEmailAddress() != null && !tempFirm.getEmailAddress().isEmpty()) {
                parameters.add("emailAddress = ?");
            }

            // Construct the SQL query dynamically
            sql.append(String.join(", ", parameters)).append(" WHERE itFirmId = ?");

            pstmt = conn.prepareStatement(sql.toString());

            // Set parameters dynamically
            int index = 1;
            if (tempFirm.getItFirmName() != null && !tempFirm.getItFirmName().isEmpty()) {
                pstmt.setString(index++, tempFirm.getItFirmName());
            }
            if (tempFirm.getCeoName() != null && !tempFirm.getCeoName().isEmpty()) {
                pstmt.setString(index++, tempFirm.getCeoName());
            }
            if (tempFirm.getEstablishedDate() != null && !tempFirm.getEstablishedDate().isEmpty()) {
                pstmt.setString(index++, tempFirm.getEstablishedDate());
            }
            if (tempFirm.getNumberOfProjectDone() != 0) {
                pstmt.setInt(index++, tempFirm.getNumberOfProjectDone());
            }
            if (tempFirm.getTotalEmployeeNumber() != 0) {
                pstmt.setInt(index++, tempFirm.getTotalEmployeeNumber());
            }
            if (tempFirm.getVacancy() != 0) {
                pstmt.setInt(index++, tempFirm.getVacancy());
            }
            if (tempFirm.getFirmType() != null && !tempFirm.getFirmType().isEmpty()) {
                pstmt.setString(index++, tempFirm.getFirmType());
            }
            if (tempFirm.getRanking() != null && !tempFirm.getRanking().isEmpty()) {
                pstmt.setString(index++, tempFirm.getRanking());
            }
            if (tempFirm.getFirmAddress() != null && !tempFirm.getFirmAddress().isEmpty()) {
                pstmt.setString(index++, tempFirm.getFirmAddress());
            }
            if (tempFirm.getContactNumber() != null && !tempFirm.getContactNumber().isEmpty()) {
                pstmt.setString(index++, tempFirm.getContactNumber());
            }
            if (tempFirm.getEmailAddress() != null && !tempFirm.getEmailAddress().isEmpty()) {
                pstmt.setString(index++, tempFirm.getEmailAddress());
            }

            // Set the WHERE clause parameter
            pstmt.setString(index, tempFirm.getItFirmId());

            // Execute the update
            int rowsUpdated = pstmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("An existing It Firm was updated successfully!");
                reloadData(); // Refresh the UI with updated data
                FileIO.reWriteItFirmInFile(itFirmList); // Update the file

                // Update the local ItFirmList
                itFirmList.updateFirm(tempFirm.getItFirmId(), tempFirm.getItFirmName(),
                        tempFirm.getCeoName(), tempFirm.getEstablishedDate(),
                        tempFirm.getNumberOfProjectDone(), tempFirm.getTotalEmployeeNumber(),
                        tempFirm.getVacancy(), tempFirm.getFirmType(),
                        tempFirm.getRanking(), tempFirm.getFirmAddress(),
                        tempFirm.getContactNumber(), tempFirm.getEmailAddress());
            } else {
                JOptionPane.showMessageDialog(this, "No matching firm found for update", "Update Error", JOptionPane.WARNING_MESSAGE);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error updating database: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            // Close resources
            try {
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
    
    public void deleteItFirmFromDatabase(String itFirmId) throws SQLException, ClassNotFoundException {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = ItFirmManagementSystem.getConnection();

            // Prepare the DELETE SQL query
            String sql = "DELETE FROM ItFirms WHERE itFirmId = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, itFirmId);

            // Execute the DELETE query
            int rowsDeleted = pstmt.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Firm deleted from the database successfully!");
            } else {
                System.out.println("No matching firm found in the database to delete.");
            }
        } finally {
            // Close resources
            if (pstmt != null) {
                pstmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
    }
    
    public ItFirm searchItFirmInDatabase(String searchInput) throws SQLException, ClassNotFoundException {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = ItFirmManagementSystem.getConnection();

            // SQL query to search by either ID or Name
            String sql = "SELECT * FROM ItFirms WHERE itFirmId = ? OR itFirmName = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, searchInput); // Search by ID
            pstmt.setString(2, searchInput); // Search by Name

            rs = pstmt.executeQuery();

            if (rs.next()) {
                // Create and return an ItFirm object from the result set
                return new ItFirm(
                    rs.getString("itFirmId"),
                    rs.getString("itFirmName"),
                    rs.getString("ceoName"),
                    rs.getString("establishedDate"),
                    rs.getInt("numberOfProjectDone"),
                    rs.getShort("totalEmployeeNumber"),
                    rs.getInt("vacancy"),
                    rs.getString("firmType"),
                    rs.getString("ranking"),
                    rs.getString("firmAddress"),
                    rs.getString("contactNumber"),
                    rs.getString("emailAddress")
                );
            }
            return null; // No matching firm found
        } finally {
            // Close resources
            if (rs != null) rs.close();
            if (pstmt != null) pstmt.close();
            if (conn != null) conn.close();
        }
    }


}



