package GUI;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement; // For parameterized queries
import java.sql.SQLException;
import java.util.Properties;


public class ItFirmManagementSystem {
    private static final String DB_URL = "jdbc:oracle:thin:@localhost:1521:xe";
    private static final String DB_USER = "ITFIRM";
    private static final String DB_PASSWORD = "ITFIRM";
     
    // Method to create and return a database connection
    public static Connection getConnection() throws SQLException, ClassNotFoundException {
        Class.forName("oracle.jdbc.OracleDriver");
        Properties properties = new Properties();
        properties.put("user", DB_USER);
        properties.put("password", DB_PASSWORD);
        return DriverManager.getConnection(DB_URL, properties);
    }
     
    // Method to close the connection
    public static void closeConnection(Connection connection) {
        if (connection != null) {
            try {
                connection.close();
                System.out.println("Connection closed.");
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
} 