package GUI;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
//import GUI.ItFirmManagement; //same package, so no need to import it
import Files.FileIO;
import java.util.prefs.Preferences;
import java.sql.Connection;        // For database connection
import java.sql.PreparedStatement; // For executing SQL queries
import java.sql.ResultSet;
import java.sql.SQLException;      // For handling SQL exceptions
import java.io.*;
import Entity.Admin;
import Database.DatabaseConnection;



public class LoginPage extends JFrame implements ActionListener{
    Font label = new Font("cambria",Font.BOLD,15);
    Font font14 = new Font("cambria",Font.PLAIN,14);

    JLabel userLabel, passLabel,titleLabel,registerLabel,subTitleLabel;
    JTextField userTextField;
    JPasswordField userPassField;
    JButton loginButton, signUpButton;
    JRadioButton adminButton, userButton, companyButton;
    JCheckBox rememberMeCheckBox;

    //ItFirmList itFirmList;
    Preferences prefs = Preferences.userNodeForPackage(LoginPage.class);
    Admin admin;

    public LoginPage() {
        super("It Firm Hub");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(400, 450);
        //this.setLocation(200, 100);
        this.setLocationRelativeTo(null); //for center
        this.setLayout(null);
        this.setResizable(false);

        //background color
        this.getContentPane().setBackground(new Color(255, 255, 255));

        /*user icon image
        userImage = new JLabel(new ImageIcon("./Images/user1.jpg"));
        userImage.setBounds(190,0,50,50);
        this.add(userImage); */

        //Welcome
        titleLabel = new JLabel("LoginSphere");
        titleLabel.setBounds(130,25,200,30);
        titleLabel.setForeground(new Color(0,0,0));
        titleLabel.setFont(new Font("Arial",Font.BOLD,25));
        this.add(titleLabel);

        subTitleLabel = new JLabel("Control And Explore");
        subTitleLabel.setBounds(210,55,200,30);
        subTitleLabel.setForeground(new Color(0,0,0));
        subTitleLabel.setFont(new Font("Cambria",Font.ITALIC,14));
        this.add(subTitleLabel);

        //Radio Buttons
        adminButton = new JRadioButton("Admin");
        userButton = new JRadioButton("User");
        companyButton = new JRadioButton("Company");

        adminButton.setBounds(70, 100, 80, 25);
        userButton.setBounds(160, 100, 80, 25);
        companyButton.setBounds(240, 100, 100, 25);

        adminButton.setFont(new Font("Cambria", Font.BOLD, 14));
        userButton.setFont(new Font("Cambria", Font.BOLD, 14));
        companyButton.setFont(new Font("Cambria", Font.BOLD, 14));

        adminButton.setBackground(new Color(255, 255, 255));
        userButton.setBackground(new Color(255, 255, 255));
        companyButton.setBackground(new Color(255, 255, 255));

        adminButton.setForeground(new Color(41, 128, 185));
        userButton.setForeground(new Color(41, 128, 185));
        companyButton.setForeground(new Color(41, 128, 185));


        adminButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        userButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        companyButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        adminButton.setFocusPainted(false);
        userButton.setFocusPainted(false);
        companyButton.setFocusPainted(false);

        userButton.setSelected(true);


        ButtonGroup roleGroup = new ButtonGroup();
        roleGroup.add(adminButton);
        roleGroup.add(userButton);
        roleGroup.add(companyButton);

        this.add(adminButton);
        this.add(userButton);
        this.add(companyButton);

        adminButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                userLabel.setText("Admin Id");
                signUpButton.setVisible(false);
                registerLabel.setVisible(false);
                rememberMeCheckBox.setVisible(false);
                userTextField.setText("");
                userPassField.setText("");
            }
        });

        userButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                userLabel.setText("Username");
                signUpButton.setVisible(true);
                registerLabel.setVisible(true);
                rememberMeCheckBox.setVisible(true);
            }
        });

        companyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                userLabel.setText("Company Id");
                signUpButton.setVisible(false);
                registerLabel.setVisible(false);
                rememberMeCheckBox.setVisible(false);
                userTextField.setText("");
                userPassField.setText("");
            }
        });

        //user name
        userLabel = new JLabel("Username");
        userLabel.setBounds(60, 125, 200, 30);
        userLabel.setForeground(new Color(0, 0, 0));
        userLabel.setFont(label);
        this.add(userLabel);

        userTextField = new JTextField();
        userTextField.setBounds(60, 165, 280, 30);
        userTextField.setBackground(new Color(230, 230, 230));
        userTextField.setFont(label);
        this.add(userTextField);

        //password
        passLabel = new JLabel("Password");
        passLabel.setBounds(60, 205, 200, 30);
        passLabel.setForeground(new Color(0, 0, 0));
        passLabel.setFont(label);
        this.add(passLabel);

        userPassField = new JPasswordField();
        userPassField.setBounds(60, 245, 280, 30);
        userPassField.setBackground(new Color(230, 230, 230));
        userPassField.setFont(label);
        userPassField.setEchoChar('*');
        this.add(userPassField);

        // Remember Me checkbox
        rememberMeCheckBox = new JCheckBox("Remember Me");
        rememberMeCheckBox.setBounds(60, 285, 200, 30);
        rememberMeCheckBox.setFont(font14);
        rememberMeCheckBox.setBackground(new Color(255, 255, 255));
        rememberMeCheckBox.setSelected(true);
        this.add(rememberMeCheckBox);

        String storeUserName = prefs.get("username","");
        String storePassword = prefs.get("password", "");
        if(!storeUserName.isEmpty() &&!storePassword.isEmpty()) {
            userTextField.setText(storeUserName);
            userPassField.setText(storePassword);
        }

        //login button
        loginButton = new JButton("Login");
        loginButton.setBounds(250, 325, 90, 30);
        loginButton.setFont(new Font("Arial", Font.BOLD, 14));
        loginButton.setBackground(new Color(39, 174, 96));
        loginButton.setForeground(Color.WHITE);
        loginButton.addActionListener(this);
        this.add(loginButton);

        //register Button
        /*registerButton = new JButton("Register");
        registerButton.setBounds(60, 290, 200, 30);
        registerButton.setFont(label);
        registerButton.setBackground(new Color(144,238,144));
        registerButton.setForeground(Color.BLACK);
        registerButton.addActionListener(this);
        this.add(registerButton);*/
        registerLabel = new JLabel("Don't have a account?");
        registerLabel.setBounds(100,375,150,30);
        registerLabel.setFont(font14);
        this.add(registerLabel);

        signUpButton = new JButton("SignUp");
        signUpButton.setBounds(240,375,50,30);
        signUpButton.setFont(new Font("cambria",Font.BOLD,14));
        signUpButton.setBorder(null);
        signUpButton.setBackground(new Color(255, 255, 255));
        signUpButton.setForeground(Color.BLUE);
        this.add(signUpButton);
        signUpButton.addActionListener(this);

        this.setVisible(true);
    }

        //click events
        public void actionPerformed(ActionEvent e) {
            if (e.getSource() == loginButton) {
                try {
                    boolean isAuthenticated = false;
                    String role;

                    if (adminButton.isSelected()) {
                        role = "Admin";
                    } else if (companyButton.isSelected()) {
                        role = "Company";
                    } else {
                        role = "User";
                    }

                    String usernameOrId = userTextField.getText();
                    String password = String.valueOf(userPassField.getPassword());

                    // Role-specific authentication
                    if ("Admin".equals(role) || "Company".equals(role)) {
                        isAuthenticated = authenticateAdmin(usernameOrId, password);
                    } else {
                        isAuthenticated = authenticateUser(usernameOrId, password);
                    }

                    if (isAuthenticated) {
                        JOptionPane.showMessageDialog(this, "Welcome " + role + ": " + usernameOrId);
                        ItFirmManagement itFirmManagement = new ItFirmManagement(role);
                        itFirmManagement.previousPage = this;
                        itFirmManagement.setVisible(true);
                        userTextField.setText("");
                        userPassField.setText("");
                        itFirmManagement.displayArea.setCaretPosition(0);
                        this.dispose(); // Close login page
                    } else {
                        JOptionPane.showMessageDialog(this, "Invalid credentials", "Login Failed", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (SQLException | ClassNotFoundException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(this, "Error during login", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else if (e.getSource() == signUpButton) {
                System.out.println("SignUp Button Clicked");
                int response = JOptionPane.showConfirmDialog(this, "Do you want to Register?", "New User", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
                if (response == JOptionPane.YES_OPTION) {
                    SignUp signUp = new SignUp();
                    signUp.previousPage = this;
                    this.setVisible(false);
                    this.dispose();
                    userTextField.setText("");
                    userPassField.setText("");
                }
            }
        }

    public boolean authenticateAdmin(String adminId, String password) throws SQLException, ClassNotFoundException {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseConnection.getConnection();
            int adminIdNumber = Integer.parseInt(adminId); // Convert adminId to integer

            String sql = "SELECT 1 FROM Admins WHERE ADMIN_ID = ? AND PASSWORD = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, adminIdNumber);
            pstmt.setString(2, password);

            rs = pstmt.executeQuery();
            if (rs.next()) {
                return true; // Admin found in database
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Admin ID must be a number", "Input Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            if (rs != null) rs.close();
            if (pstmt != null) pstmt.close();
            if (conn != null) conn.close();
        }

        // Fallback to file-based authentication
        Admin admin = FileIO.loadAdminFromFile(adminId, password);
        return admin != null; // Return true if admin is found in the file
    }




    public boolean authenticateUser(String username, String password) throws SQLException, ClassNotFoundException {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = ItFirmManagementSystem.getConnection(); // Ensure correct database connection

            // Use ITFIRM schema explicitly
            String sql = "SELECT password FROM ITFIRM.Users WHERE LOWER(username) = LOWER(?)";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, username);
            rs = pstmt.executeQuery();

            if (rs.next()) { // If username exists
                String storedPassword = rs.getString("password");

                // Debug: Print stored and entered passwords
                System.out.println("Stored Password: [" + storedPassword + "]");
                System.out.println("Entered Password: [" + password + "]");

                if (storedPassword.trim().equals(password.trim())) {
                    System.out.println("Login Successful!");
                    return true;
                } else {
                    System.out.println("❌ Password does not match!");
                }
            } else {
                System.out.println("❌ Username not found in database.");
            }
        } finally {
            if (rs != null) rs.close();
            if (pstmt != null) pstmt.close();
            if (conn != null) conn.close();
        }

        return false; // Login failed
    }


}
