package GUI;

import javax.swing.*;
import java.awt.*;
import Files.FileIO;

public class ProjectDetailsDialog extends JDialog {
    private Font labelFont = new Font("Cambria", Font.BOLD, 14);
    private Font fieldFont = new Font("Segoe UI", Font.PLAIN, 14);

    private JTextField projectIdField, projectNameField, projectTypeField;
    private JTextField startDateField, endDateField, statusField, budgetField, itFirmIdField;
    private JButton submitButton, cancelButton;

    public ProjectDetailsDialog() {
        setTitle("Add Project Details");
        setModal(true);
        setSize(450, 550);  // Increased height to accommodate buttons
        setLocationRelativeTo(null);
        setLayout(null);
        getContentPane().setBackground(new Color(245, 245, 245));

        int labelX = 40;
        int fieldX = 180;
        int startY = 40;
        int height = 30;
        int gap = 50;
        int width = 200;

        // Project ID
        JLabel projectIdLabel = new JLabel("Project ID:");
        projectIdLabel.setBounds(labelX, startY, width, height);
        projectIdLabel.setFont(labelFont);
        add(projectIdLabel);

        projectIdField = new JTextField();
        projectIdField.setBounds(fieldX, startY, width, height);
        projectIdField.setFont(fieldFont);
        projectIdField.setBackground(new Color(255, 255, 255));
        add(projectIdField);

        // Project Name
        JLabel projectNameLabel = new JLabel("Project Name:");
        projectNameLabel.setBounds(labelX, startY += gap, width, height);
        projectNameLabel.setFont(labelFont);
        add(projectNameLabel);

        projectNameField = new JTextField();
        projectNameField.setBounds(fieldX, startY, width, height);
        projectNameField.setFont(fieldFont);
        projectNameField.setBackground(new Color(255, 255, 255));
        add(projectNameField);

        // Project Type
        JLabel projectTypeLabel = new JLabel("Project Type:");
        projectTypeLabel.setBounds(labelX, startY += gap, width, height);
        projectTypeLabel.setFont(labelFont);
        add(projectTypeLabel);

        projectTypeField = new JTextField();
        projectTypeField.setBounds(fieldX, startY, width, height);
        projectTypeField.setFont(fieldFont);
        projectTypeField.setBackground(new Color(255, 255, 255));
        add(projectTypeField);

        // Start Date
        JLabel startDateLabel = new JLabel("Start Date:");
        startDateLabel.setBounds(labelX, startY += gap, width, height);
        startDateLabel.setFont(labelFont);
        add(startDateLabel);

        startDateField = new JTextField();
        startDateField.setBounds(fieldX, startY, width, height);
        startDateField.setFont(fieldFont);
        startDateField.setBackground(new Color(255, 255, 255));
        add(startDateField);

        // End Date
        JLabel endDateLabel = new JLabel("End Date:");
        endDateLabel.setBounds(labelX, startY += gap, width, height);
        endDateLabel.setFont(labelFont);
        add(endDateLabel);

        endDateField = new JTextField();
        endDateField.setBounds(fieldX, startY, width, height);
        endDateField.setFont(fieldFont);
        endDateField.setBackground(new Color(255, 255, 255));
        add(endDateField);

        // Status
        JLabel statusLabel = new JLabel("Status:");
        statusLabel.setBounds(labelX, startY += gap, width, height);
        statusLabel.setFont(labelFont);
        add(statusLabel);

        statusField = new JTextField();
        statusField.setBounds(fieldX, startY, width, height);
        statusField.setFont(fieldFont);
        statusField.setBackground(new Color(255, 255, 255));
        add(statusField);

        // Budget
        JLabel budgetLabel = new JLabel("Budget:");
        budgetLabel.setBounds(labelX, startY += gap, width, height);
        budgetLabel.setFont(labelFont);
        add(budgetLabel);

        budgetField = new JTextField();
        budgetField.setBounds(fieldX, startY, width, height);
        budgetField.setFont(fieldFont);
        budgetField.setBackground(new Color(255, 255, 255));
        add(budgetField);

        // IT Firm ID
        JLabel itFirmIdLabel = new JLabel("IT Firm ID:");
        itFirmIdLabel.setBounds(labelX, startY += gap, width, height);
        itFirmIdLabel.setFont(labelFont);
        add(itFirmIdLabel);

        itFirmIdField = new JTextField();
        itFirmIdField.setBounds(fieldX, startY, width, height);
        itFirmIdField.setFont(fieldFont);
        itFirmIdField.setBackground(new Color(255, 255, 255));
        add(itFirmIdField);

        // Buttons - with adjusted positions
        int buttonY = startY + gap + 20;
        cancelButton = new JButton("Cancel");
        cancelButton.setBounds(fieldX - 50, buttonY, 100, height);
        cancelButton.setFont(labelFont);
        cancelButton.setBackground(new Color(231, 76, 60));
        cancelButton.setForeground(Color.WHITE);
        add(cancelButton);

        submitButton = new JButton("Submit");
        submitButton.setBounds(fieldX + 70, buttonY, 100, height);
        submitButton.setFont(labelFont);
        submitButton.setBackground(new Color(39, 174, 96));
        submitButton.setForeground(Color.WHITE);
        add(submitButton);

        // Add action listeners
        cancelButton.addActionListener(e -> dispose());

        submitButton.addActionListener(e -> {
            try {
                // Validate required fields
                if (projectIdField.getText().isEmpty() || projectNameField.getText().isEmpty() ||
                        itFirmIdField.getText().isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Please fill in all required fields",
                            "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Parse budget to double
                double budgetValue = 0.0;
                try {
                    if (!budgetField.getText().isEmpty()) {
                        budgetValue = Double.parseDouble(budgetField.getText());
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(this, "Invalid budget format",
                            "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Save to file
                FileIO.writeProjectInFile(
                        projectIdField.getText(),
                        projectNameField.getText(),
                        projectTypeField.getText(),
                        startDateField.getText(),
                        endDateField.getText(),
                        statusField.getText(),
                        budgetValue,
                        itFirmIdField.getText()
                );

                JOptionPane.showMessageDialog(this, "Project saved successfully!");
                dispose();

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error saving project: " + ex.getMessage(),
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    }
}
