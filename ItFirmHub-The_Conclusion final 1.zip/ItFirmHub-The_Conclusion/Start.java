// Initializes an IT firm list and creates a login page instance for a GUI application.
//import Entity.ItFirm;
import EntityList.ItFirmList;
//import GUI.ItFirmManagement;
import GUI.LoginPage;
//import GUI.SignUp;

public class Start {
    public static void main(String[] args) {
    ItFirmList itFirmList= new ItFirmList();

      LoginPage loginPage = new LoginPage();
      //ItFirmManagement itFirmManagement = new ItFirmManagement(itFirmList);
       // SignUp signUp = new SignUp();
    }
}
